from typing import List, Optional
import mammoth
from bs4 import BeautifulSoup, NavigableString, Tag
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT


def parse_document(file_path: str) -> str:
    try:
        with open(file_path, "rb") as docx_file:
            result = mammoth.convert_to_html(docx_file)
            html = result.value  # The generated HTML
            return html
    except FileNotFoundError:
        return "Error: The file was not found."
    except IOError:
        return "Error: There was an IO error opening the file."
    except Exception as e:
        return f"An unexpected error occurred: {str(e)}"


def parse_section_names(file_path: str) -> List[str]:
    try:
        html_content = parse_document(file_path)
        
        # Check if html_content is an error message instead of valid HTML
        if html_content.startswith("Error:"):
            return [html_content]

        soup = BeautifulSoup(html_content, 'html.parser')

        # Check if there are any h1 tags in the document
        if soup.find_all('h1'):
            section_names = [h1.get_text(strip=True) for h1 in soup.find_all('h1')]
        else:
            return ["No section names found in the document."]
        
        return section_names

    except Exception as e:
        return [f"An unexpected error occurred: {str(e)}"]


def parse_section_content(file_path: str, section_name: str) -> Optional[str]:
    try:
        html_content = parse_document(file_path)

        # Check if html_content is an error message instead of valid HTML
        if html_content.startswith("Error:"):
            return html_content

        soup = BeautifulSoup(html_content, 'html.parser')

        for h1 in soup.find_all('h1'):
            if h1.get_text(strip=True) == section_name:
                content = ''
                for sibling in h1.next_siblings:
                    if isinstance(sibling, NavigableString):
                        continue

                    if sibling.name == 'h1':  # Stop if another h1 tag is encountered
                        break

                    if sibling.name in ['table', 'p', 'img']:
                        sibling['class'] = sibling.get('class', []) + [f'section-{sibling.name}']

                    content += str(sibling)
                return content
        return "Section name not found."

    except Exception as e:
        return f"An unexpected error occurred: {str(e)}"
    