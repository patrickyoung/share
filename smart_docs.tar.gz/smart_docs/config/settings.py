# config/settings.py
OPENAI_API_KEY = "your_openai_api_key_here"
