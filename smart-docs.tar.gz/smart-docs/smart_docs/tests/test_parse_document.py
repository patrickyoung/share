from skills.word import parse_document


def test_valid_document_conversion():
    """Description: Test with a valid .docx file and verify that the function returns the correct HTML.
    Expectation: The function should return HTML content."""

    # Path to a valid .docx file (for the sake of this example, it's just a string)
    file_path = "./tests/test_files/FlavorWhiz_Design_Specification.docx"

    # Call the function
    result = parse_document(file_path)

    # Assert that the result is as expected
    assert isinstance(result, str)
    assert "<p>System Design for FlavorWhiz</p>" in result  # or other assertions based on expected HTML output


def test_with_nonexistent_file_path():
    """
    Description: Pass a file path that doesn't exist to the function.
    Expectation: The function should return the "Error: The file was not found." message."""
    # Provide a file path that does not exist
    nonexistent_file_path = "path/to/nonexistent/document.docx"

    # Call the function with the nonexistent file path
    result = parse_document(nonexistent_file_path)

    # Assert that the function returns the correct error message
    assert result == "Error: The file was not found."


def test_with_invalid_file_type():
    """
    Description: Provide a path to a file that is not a .docx format, such as a .txt or .pdf file.
    Expectation: Depending on how mammoth.convert_to_html handles non-.docx files, this should either return an error message or possibly an empty string. This test will help ensure that the function handles unexpected file formats gracefully.
    """
    # Provide a file path to a non-.docx file
    invalid_file_path = "./tests/test_files/invalid_file_type.txt"

    # Call the function with the invalid file path
    result = parse_document(invalid_file_path)

    # Depending on how 'mammoth.convert_to_html' handles non-.docx files,
    # the assertion here may vary. If it throws an exception, you should assert that.
    # If it returns an empty string or some specific error message, assert that instead.

    # Example: Asserting an empty string or specific error message
    assert "An unexpected error occurred" in result  # or replace with the expected error message

# More tests:

# Test with Corrupted .docx File:

#     Description: Pass a corrupted .docx file to the function.
#     Expectation: The function should return an error message that an unexpected error occurred.

# Test with Empty .docx File:

#     Description: Use an empty .docx file.
#     Expectation: The function should return an empty string or HTML structure with no body content.

# Test with Large .docx File:

#     Description: Test the function with a very large .docx file to check how it handles large inputs.
#     Expectation: The function should successfully return the HTML content, but this test can also check for performance issues.

# Test IO Error:

#     Description: Simulate an IO error, such as file read permissions issues.
#     Expectation: The function should return the "Error: There was an IO error opening the file." message.
