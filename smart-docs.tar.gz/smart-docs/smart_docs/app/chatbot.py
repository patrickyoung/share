# app/chatbot.py
import openai
from config.settings import OPENAI_API_KEY

class ChatGPT:
    def __init__(self, settings):
        settings.api_key = OPENAI_API_KEY

    def ask_question(self, question):
        response = openai.Completion.create(
            engine="davinci", 
            prompt=question, 
            max_tokens=150
        )
        return response.choices[0].text.strip()
