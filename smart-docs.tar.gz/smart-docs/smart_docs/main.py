from openai import OpenAI
import json
from skills import word


client = OpenAI()


def get_sections_from_doc(doc_type):
    sections = word.parse_section_ids("./tests/FlavorWhiz Design Specification.docx")
    return json.dumps(sections)

available_functions = {
    "get_sections_from_doc": get_sections_from_doc
}


def run_conversation():
    messages = [{"role": "user", "content": "What are the sections of the document?"}]
    tools = [
        {
            "type": "function",
            "function": {
                "name": "get_sections_from_doc",
                "description": "Get the list of sections from a given document format",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "doc_type": {
                            "type": "string",
                            "description": "The type of document to process",
                        },
                    },
                    "required": ["doc_type"],
                },
            },
        }
    ]
    response = client.chat.completions.create(
        model="gpt-3.5-turbo-1106",
        messages=messages,
        tools=tools,
        tool_choice="auto",  # auto is default, but we'll be explicit
    )
    response_message = response.choices[0].message
    tool_calls = response_message.tool_calls

    for tool_call in tool_calls:
        function_name = tool_call.function.name
        function_to_call = available_functions[function_name]
        function_args = json.loads(tool_call.function.arguments)
        function_response = function_to_call(
            doc_type=function_args.get("doc_type"),
        )
        messages.append(
            {
                "tool_call_id": tool_call.id,
                "role": "tool",
                "name": function_name,
                "content": function_response,
            }
        )  # extend conversation with function response
        print(messages)
    # second_response = client.chat.completions.create(
    #     model="gpt-3.5-turbo-1106",
    #     messages=messages,
    # )  # get a new response from the model where it can see the function response
    # return second_response


if __name__ == "__main__":
    run_conversation()